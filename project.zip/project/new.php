<!DOCTYPE html>
<html>
<head>
	
	<title>New Movies</title>
	<link rel="shortcut icon" type="robot.png" href="Logo.png">
	<link href="style.css" rel="stylesheet"/>
</head>
<body>

<div id="nav1">
<h3><font color="orange" face="Algerian">4K</font><font size="6">MOVIES</font></h3>
</div>
<hr color="grey">

<nav class="menu">
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="hollywood.php">Hollywood</a></li>
        <li><a href="new.php">New</a></li>
        <li><a href="urdu.php">Urdu Dubed</a></li>
        <li><a href="year.php">Year</a></li>
    </ul>
<form class="search-form">
 <input type="text" placeholder="Search">
 <button>Search</button>
 </form>    
</nav>	


<div class="title">
	
	<div class="items">
        <a href="1.php">
		<img src="1.jpg" class="item-image"/>
        <div class="image-title">Goosebumps<br>(2014)</div></a>
	</div>

	<div class="items">
	    <a href="3.php">
		<img src="3.jpg" class="item-image"/>
        <div class="image-title">Wonder Park <br>(2019)</div></a>
	</div>

<div class="items">
		<a href="5.php">
		<img src="5.jpg" class="item-image"/>
		<div class="image-title">WreckIt Ralf<br>(2019)</div></a>
	</div>

	<div class="items">
		<a href="18.php">
			<img src="18.jpg" class="item-image"/>
        <div class="image-title">Tom & Jerry<br>(2021)</div></a>
    </div>

	<div class="items">
		<a href="17.php">
		<img src="17.jpg" class="item-image"/>
        <div class="image-title">Raya The Last Dragon<br>(2021)</div></a>
    </div>

	<div class="items">
	    <a href="16.php">
        <img src="16.jpg" class="item-image"/>
        <div class="image-title">Epic <br>(2009)</div></a>
	</div>

	<div class="items">
	    <a href="7.php">
		<img src="7.png" class="item-image"/>
        <div class="image-title">Goosebumps 2 <br>(2019)</div></a>
	</div>

	<div class="items">
		<a href="9.php">
		<img src="9.jpg" class="item-image"/>
		<div class="image-title">Dumbo<br>(2019)</div></a>
	</div>

	<div class="items">
	    <a href="11.php">
		<img src="11.jpg" class="item-image"/>
        <div class="image-title">Angry Bird Movie 2 <br>(2019)</div></a>
	</div>

	<div class="items">
		<a href="13.php">
		<img src="13.jpg" class="item-image"/>
		<div class="image-title">Coco<br>(2017)</div></a>
	</div>

	<div class="items">
	    <a href="15.php">
			<img src="15.jpg" class="item-image"/>
        <div class="image-title">Cars 3<br>(2019)</div></a>
	</div>

	<div class="items">
        <a href="2.php">
        <img src="2.jpeg" class="item-image"/>
        <div class="image-title">The BFG<br>(2016)</div></a>
	</div>
	
	<div class="items">
		<a href="4.php">
		<img src="4.jpg" class="item-image"/>
        <div class="image-title">How To Train Your<br> Dragon (2018)</div></a>
    </div>

	<div class="items">
        <a href="6.php">
		<img src="6.jpg" class="item-image"/>
        <div class="image-title">Hotel Transylvania 3<br>(2019)</div></a>
	</div>

	<div class="items">
		<a href="8.php">
			<img src="8.jpeg" class="item-image"/>
        <div class="image-title">The Jungle Book<br>(2016)</div></a>
    </div>

	<div class="items">
        <a href="10.php">
		<img src="10.jpg" class="item-image"/>
        <div class="image-title">The Gretest Showman<br>(2018)</div></a>
	</div>

</div>


<div class="ad">
	<div class="ae"><a href="hollywood.php">
	<input type="button" name="buton" value="&laquo;">	
	<input type="button" name="buton" value="1">
	<input type="button" name="buton" value="2">
	<input type="button" name="buton" value="3">
	<input type="button" name="buton" value="4">
	<input type="button" name="buton" value="&raquo;"></a>
</div></div>


<div id="footer">
<div class="bun">
<input type="button" value="FMOVIES">
</div></div>

<div id="footer1">
<b>fmovies- Free movies oline,</b>here you can watch movies online in high quality for free without annoying of advertising,	just come and enjoy your movies
	online. fmovie,fmovies,bmovie</br></br>   
<b>Connect with us on twitter</b></br>   </br>	

</body>
</html>