<!DOCTYPE html>
<html>
<head>

  <title>Movies</title>
  <link rel="shortcut icon" type="robot.png" href="Logo.png">
  <link href="style2.css" rel="stylesheet"/>

</head>
<body>

<div id="nav1">
<h3><font color="orange" face="Algerian">4K</font><font size="6">MOVIES</font></h3>
<div class="butn"><a href="index.php">Home</a></div></div>
	
<div class="cc">
		<h2 align="center">Download Coco (2017) {Dual Audio With Subtitles} WeB-DL HD 480p [700MB] || 720p [1.8GB] || 1080p [7GB]</h2><br>
<table>
	<tr>
		<td width="50%" rowspan="2"><img src="13.jpg" width="90%" height="378px"></td>
		<td><font size="6px" color="orange"><b>Coco (2017) Full Movie</b></font><br><br><b>Genre</b> : Action / Fantacy / Adventure / Thriler<br><br><b>Language:</b> English / Urdu Dubbed<br><br><b>Duration</b> : 1H / 29Min <br><br><b>Release Date</b> : March 2017<br><br><b>  IMBD</b> : 4.5<br> </td>	
	</tr>

	<tr>
			<td align="center"><abbr title="Download This Movie Free">
        <a href="login.php"><input type="button" name="button" value="Download Now"></a><a href="https://www.youtube.com/watch?v=Rvr68u6k5sI"><input type="button" name="button" value="Watch Now"></a></abbr></td>
	</tr>

</table>
</div>

<div id="footer"><center>Copyright © 2012 2021 - 4K Movies.com</center></div>

</body>
</html> 