
<!DOCTYPE html>
<html>
<head>

  <title>Login Form</title>
  <link rel="shortcut icon" type="robot.png" href="Logo.png">
<style>

body{
  background-image: url(back.jpg);
  background-repeat: no-repeat;
  background-size: 100%;
  background-attachment: fixed;
} 
   *{  margin:0px;
  padding:0px;}
  
#nav1{
  width:100%;
  height:7vh;
  margin:auto;
  border-radius:0px;
  background-color:#171717;
  text-align:left;
  font-size:40px;
  color:white;
  font-family:"Arial Black", Gadget,sans-serif;
  border-top:solid 3px #ed7d31;
  border-bottom:solid 3px #ed7d31;}
h3{ margin-top: -1%; }

.btn4{
  border:solid 2px white;
  width:8%;
  margin-left:90%;
  margin-top: -3.5%;
  position: absolute;
  cursor: pointer;
  background-color:white;
  border-radius:12px;
  color:#ed7d31;
  font-size:24px;}

.btn4:hover{
  background-color: #ed7d31;
  color:white;}

.cc {
  border-radius: 5px;
  width: 40%;
  height: 60vh;
  font-size: 20px;
  margin-left: 30px;
  opacity: 0.9;
  background-color:rgb(204, 204, 204);
  padding: 20px;
}

.cc1 {
  border-radius: 5px;
  width: 40%;
  height: 60vh;
  font-size: 20px;
  position: absolute;
  right: 30px;
  top:20%;
  opacity: 0.9;
  background-color:rgb(204, 204, 204);
  padding: 20px;
}

input[type=text], select {
  width: 100%;
  padding:12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=password], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}


input[type=submit] {
  width: 49%;
  background-color: white;
  color: black;
  font-size: 15px;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[value=Rigister] {
  width: 100%;
  background-color: white;
  color: black;
  font-size: 15px;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color:#ed7d31;
  color: white;
  font-size: 18px;
}

input[type=button] {
  width: 100%;
  background-color: white;
  color: black;
  font-size: 15px;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=button]:hover {
  background-color:#ed7d31;
  color: white;
  font-size: 18px;
}

h1{
  font-size: 40px;
  color: #ed7d31;
}


#footer{
  width: 100%;
  margin-top: 4%;
  height: 27px;
  opacity: 0.8;
  color: white;
  padding-top: 10px;
  font-size: 20px;
  border-radius: 3px;
  background-color:grey;
}

</style>

</head>
<body>


<div id="nav1">
<h3><font color="#ed7d31" face="Algerian">4K</font><font size="6">MOVIES</font> </h3>
<a href="index.php"><button class="btn4">Home</button></a> 
</div> 


<br><br><br><br>
<div class="cc">
<h1>Login Form</h1>


  <form action="validation.php" method="post">
    <label for="fname">Email</label>
    <input type="text" id="fname" name="user" placeholder="Enter Email @..">

    <label for="lname">Password</label>
    <input type="password" id="lname" name="password" placeholder="Enter Password..">
    
    <label for="lname">Credit Card No #</label>
    <input type="password" id="lname" placeholder="xxxx-xxxxxxxxx-xxxx"><br><br>

    <input type="submit" value="Submit">
     <input type="submit" value="Forget Password">
  </form>
</div>


<div class="cc1">
<h1>Registration Form</h1>

  <form action="registration.php" method="POST">
    <label for="fname">Username Name</label>
    <input type="text" id="fname" name="name" placeholder="Enter Movie Name..">

    <label for="fname">Email</label>
    <input type="text" id="fname" name="user" placeholder="Enter Movie Name..">

    <label for="lname">Password</label>
    <input type="password" id="lname" name="password" placeholder="Enter Password.."><br><br>
  
    <input type="submit" value="Rigister">
  </form>
</div>


<div id="footer"><center>Copyright © 2012 2021 - 4K Movies.com</center></div>


</body>
</html>