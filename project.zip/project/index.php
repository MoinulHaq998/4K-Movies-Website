<html>
<head>
	<title>Home Page</title>
	<link rel="shortcut icon" type="robot.png" href="Logo.png">
	<link href="style3.css" rel="stylesheet"/>
</head>

<body>  
<div id="nav1">
<h3><font color="orange" face="Algerian">4K</font><font size="6">MOVIES</font></h3>
<div class="butn"><a href="login.php">
<input type="button" value="Sign Up"></a>
</div></div>

<hr color="grey">


<div id="body">
<div class="slider" >
	<span style="--i:1"><img src="1.jpg"></span>
	<span style="--i:2"><img src="2.jpeg"></span>
	<span style="--i:3"><img src="3.jpg"></span>	
	<span style="--i:4"><img src="4.jpg"></span>	
	<span style="--i:5"><img src="5.jpg"></span>	
	<span style="--i:6"><img src="7.png"></span>
	<span style="--i:7"><img src="12.jpg"></span>
	<span style="--i:8"><img src="21.jpg"></span>
</div></div>


<nav class="menu">
    <ul>
        <li><a href="Index.php">Home</a></li>
        <li><a href="hollywood.php">Hollywood</a></li>
        <li><a href="new.php">New</a></li>
        <li><a href="urdu.php">Urdu Dubed</a></li>
        <li><a href="year.php">Year</a></li>
    </ul>
<form class="search-form">
 <input type="text" placeholder="Find Your Faverate Movie">
 <button>Search</button>
 </form>    
</nav>


<div class="title">
	
	<div class="items">
        <a href="1.php">
		<img src="1.jpg" class="item-image"/>
        <div class="image-title">Goosebumps<br>(2014)</div></a>
	</div>

	<div class="items">
        <a href="2.php">
        <img src="2.jpeg" class="item-image"/>
        <div class="image-title">The BFG<br>(2016)</div></a>
	</div>
	
	<div class="items">
	    <a href="3.php">
		<img src="3.jpg" class="item-image"/>
        <div class="image-title">Wonder Park <br>(2019)</div></a>
	</div>

	<div class="items">
		<a href="4.php">
		<img src="4.jpg" class="item-image"/>
        <div class="image-title">How To Train Your<br> Dragon (2018)</div></a>
    </div>

	<div class="items">
		<a href="5.php">
		<img src="5.jpg" class="item-image"/>
		<div class="image-title">WreckIt Ralf<br>(2019)</div></a>
	</div>

	<div class="items">
        <a href="6.php">
		<img src="6.jpg" class="item-image"/>
        <div class="image-title">Hotel Transylvania 3<br>(2019)</div></a>
	</div>
	
	<div class="items">
	    <a href="7.php">
		<img src="7.png" class="item-image"/>
        <div class="image-title">Goosebumps 2 <br>(2019)</div></a>
	</div>

	<div class="items">
		<a href="8.php">
			<img src="8.jpeg" class="item-image"/>
        <div class="image-title">The Jungle Book<br>(2016)</div></a>
    </div>

	<div class="items">
		<a href="9.php">
		<img src="9.jpg" class="item-image"/>
		<div class="image-title">Dumbo<br>(2019)</div></a>
	</div>

	<div class="items">
        <a href="10.php">
		<img src="10.jpg" class="item-image"/>
        <div class="image-title">The Gretest Showman<br>(2018)</div></a>
	</div>
	
	<div class="items">
	    <a href="11.php">
		<img src="11.jpg" class="item-image"/>
        <div class="image-title">Angry Bird Movie 2 <br>(2019)</div></a>
	</div>

	<div class="items">
        <a href="12.php">
		<img src="12.jpg" class="item-image"/>
        <div class="image-title">Christopher Robin<br>(2017)</div></a>
	</div>

	<div class="items">
		<a href="13.php">
		<img src="13.jpg" class="item-image"/>
		<div class="image-title">Coco<br>(2017)</div></a>
	</div>
	
	<div class="items">
        <a href="14.php">
		<img src="14.jpg" class="item-image"/>
        <div class="image-title">Teen Titans<br>(2018)</div></a>
	</div>
	
	<div class="items">
	    <a href="15.php">
		<img src="15.jpg" class="item-image"/>
        <div class="image-title">Cars 3<br>(2019)</div></a>
	</div>	
	
	<div class="items">
	    <a href="16.php">
        <img src="16.jpg" class="item-image"/>
        <div class="image-title">Epic <br>(2009)</div></a>
	</div>
	
	<div class="items">
		<a href="17.php">
		<img src="17.jpg" class="item-image"/>
        <div class="image-title">Raya The Last Dragon<br>(2021)</div></a>
    </div>
	
	<div class="items">
		<a href="18.php">
		<img src="18.jpg" class="item-image"/>
        <div class="image-title">Tom & Jerry<br>(2021)</div></a>
    </div>

	<div class="items">
		<a href="19.php">
		<img src="19.jpg" class="item-image"/>
		<div class="image-title">Boss Baby<br>(2021)</div></a>
	</div>

	<div class="items">
		<a href="20.php">
		<img src="20.jpeg" class="item-image"/>
		<div class="image-title">Artemis Fowl<br>(2020)</div></a>
	</div>

</div>


<div class="ad">
	<div class="ae"><a href="new.php">
	<input type="button" name="buton" value="&laquo;">	
	<input type="button" name="buton" value="1">
	<input type="button" name="buton" value="2">
	<input type="button" name="buton" value="3">
	<input type="button" name="buton" value="4">
	<input type="button" name="buton" value="&raquo;"></a>
</div></div>



<div id="footer"><a href="#">
<div class="bun">
<input type="button" value="4K MOVIES">
</div></a></div>

<div id="footer1">
<b>fmovies- Free movies oline,</b>here you can watch movies online in high quality for free without annoying of advertising,	
just come and enjoy your movies </br>
	online. fmovie,fmovies,bmovie</br></br>   
<b>Connect with us on twitter</b></br>   </br>	

<div id="siz">	     
	<ul> 
		<li><a href="new.php">Latest Movies/Shows</a></li>
        <li><a href="#">9anime</a></li>
        <li><a href="#">United state</a></li>
        <li><a href="#">Request</a></li>
    </ul>
     <ul>
		<li><a href="new.php">Action</a></li>
        <li><a href="#">GoStrem</a></li>
        <li><a href="#">United Kingdom</a></li>
        <li><a href="#">Blog</a></li>
     </ul>
	 <ul>
		<li><a href="new.php">Adventure</a></li>
        <li><a href="#">123Mvies</a></li>
		<li><a href="#">India</a></li>
        <li><a href="#">Sitemap</a></li>
     </ul>
	<ul>
		<li><a href="new.php">Kungfu</a></li>
        <li><a href="#">Putlocker</a></li>
		<li><a href="#">Pakistan</a></li>
        <li><a href="#">DCMA</a></li>
     </ul>
	<ul>
		<li><a href="new.php">Thriller</a></li>
        <li><a href="#">Whatchfree</a></li>
        <li><a href="#">China</a></li>
        <li><a href="#">FAQ</a></li>
     </ul>
	<ul>
		<li><a href="new.php">Sci-fi</a></li>
        <li><a href="#">CmoviesHD</a></li>
     </ul>
</div></div>
 	
</body>
</html>